package DSPPCode.hadoop.multi_input_join;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ReduceJoinReducerImpl extends ReduceJoinReducer {
    @Override
    protected void reduce(Text key, Iterable<TextPair> values, Context context) throws IOException, InterruptedException {
        ArrayList<Text> order_id = new ArrayList();
        ArrayList<Text> person = new ArrayList();
        TextPair output = new TextPair();

        for(TextPair tp : values)
        {
            if (tp.getFlag().toString().equals("Person"))
            {
                Text name = new Text();
                name.set(tp.getData());
                person.add(name);
                System.out.println("getdata" + "\t" + output.getData());
            }
            else if (tp.getFlag().toString().equals("Order"))
            {
                Text o_id = new Text();
                o_id.set(tp.getData());
                order_id.add(o_id);
                System.out.println("getflag" + "\t" + o_id);
            }
        }

        if(!person.isEmpty() && !order_id.isEmpty())
        {
            for(Text p: person)
            {
                output.setData(p);
                for (Text o: order_id)
                {
                    output.setFlag(o);
                    context.write(new Text(output.toString() +  "\t"), NullWritable.get());
                }
            }
        } else return;
    }
}
