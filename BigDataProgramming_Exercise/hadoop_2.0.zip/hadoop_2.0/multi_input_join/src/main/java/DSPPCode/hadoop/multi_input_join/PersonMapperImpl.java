package DSPPCode.hadoop.multi_input_join;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

import java.io.IOException;

public class PersonMapperImpl extends PersonMapper{
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String[] values = value.toString().split("\t");
        String lstname = null;
        String fstname = null;
        String id_p = null;
        if (values.length>2)
        {
            id_p = values[0];
            lstname = values[1];
            fstname = values[2];
            context.write(new Text(id_p), new TextPair(new Text(lstname+ "\t" +fstname), new Text("Person")));
//            System.out.println(id_p + "\t" + lstname+ "\t" +fstname);
        }
    }

}
