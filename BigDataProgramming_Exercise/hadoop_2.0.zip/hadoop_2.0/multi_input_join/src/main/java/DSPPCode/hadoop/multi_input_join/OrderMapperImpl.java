package DSPPCode.hadoop.multi_input_join;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

import java.io.IOException;

public class OrderMapperImpl extends OrderMapper {
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String[] values = value.toString().split("\t");
        if (values.length>2)
        {
            String id_p = values[2];
            String order_id = values[1];
            context.write(new Text(id_p), new TextPair(new Text(order_id), new Text("Order")));
//            System.out.println(order_id);
//            System.out.println(id_p + "\t" + order_id);
        }
    }
}
