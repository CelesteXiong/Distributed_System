# Simple Shortest Paths

## 待完成:

* 请在 DSPPCode.hadoop.ssp 中创建 SimpleShortestPathsMapperImpl, 继承 SimpleShortestPathsMapper, 实现虚函数
* 请在 DSPPCode.hadoop.ssp 中创建 SimpleShortestPathsReducerImpl, 继承 SimpleShortestPathsReducer, 实现虚函数

## 题目描述:

* 使用 Hadoop 实现 simple shortest paths. 输出从 A 点出发到其余各点的最短距离
