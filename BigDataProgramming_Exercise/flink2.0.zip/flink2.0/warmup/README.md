# Word Count

## 待完成:

* 请在DSPPCode.flink.stream_warm_up中创建WordCountImpl, 继承WordCount, 实现虚函数.

## 题目描述:

* 对单词进行计数.
