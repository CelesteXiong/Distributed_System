package DSPPCode.storm.slide_count_window;

import org.apache.storm.topology.BasicOutputCollector;
import org.apache.storm.tuple.Tuple;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;

public class SlideCountWindowBoltImpl extends SlideCountWindowBolt {
    @Override
    public void execute(Tuple tuple, BasicOutputCollector basicOutputCollector) {
        String w = tuple.getString(0);
        String c = tuple.getString(1);
        ArrayList<String> v = new ArrayList<>();
        if (!counter.containsKey(w))
        {
            v.add(c);
            v.add("1");
            v.add("1");
            counter.put(w, v);
        }
        else if (counter.containsKey(w))
        {

            ArrayList<String> oldv = counter.get(w);
            int count = Integer.parseInt(oldv.get(1));
            String newv = oldv.get(0);
            String new_wn = oldv.get(2);
            String new_c = oldv.get(1);
            if (count+1 == 2)
            {
                String emit = outputFormat(w,oldv.get(0)+c, new_wn);
                basicOutputCollector.emit(Collections.singletonList(emit));
                newv = (newv+c).substring((newv+c).length()-1);
                new_c = "0";
                new_wn = Integer.toString(Integer.parseInt(new_wn)+1);
            }
            else
            {
                newv = newv + c;
                new_c = Integer.toString(Integer.parseInt(new_c)+1);
            }
            v.add(newv);
            v.add(new_c);
            v.add(new_wn);
            counter.put(w,v);
        }

    }
}
