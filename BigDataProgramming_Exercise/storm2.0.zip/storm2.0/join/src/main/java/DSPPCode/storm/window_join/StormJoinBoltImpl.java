package DSPPCode.storm.window_join;

import org.apache.storm.bolt.JoinBolt;
import org.apache.storm.topology.base.BaseWindowedBolt;

import java.util.concurrent.TimeUnit;

public class StormJoinBoltImpl extends StormJoinBolt {
    @Override
    public void setJoinBolt() {

    }

    @Override
    public JoinBolt getJoinBolt() {
        return new JoinBolt("genderSpout", "id")
        .join("ageSpout", "id","genderSpout")
        .select("id, gender, age")
        .withTumblingWindow(new BaseWindowedBolt.Duration(2, TimeUnit.SECONDS));
    }
}
