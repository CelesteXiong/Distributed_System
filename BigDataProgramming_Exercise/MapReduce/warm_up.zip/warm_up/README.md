# Word Count

## 待完成:

* 请在DSPPCode.hadoop.warm_up中创建TokenizerMapperImpl, 继承TokenizerMapper, 实现虚函数.

* 请在DSPPCode.hadoop.warm_up中创建IntSumReducerImpl, 继承IntSumReducer, 实现虚函数.

## 题目描述:

* 对单词进行计数.
